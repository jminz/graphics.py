#!/usr/bin/env python
from distutils.core import setup
setup(name='graphics',
            version='0.1',
            py_modules=['graphics'],
            description='setup graphics',
            author='none',
            author_email='none',
            url='localhost'
           )
